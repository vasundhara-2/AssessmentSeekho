package com.uniquelist.assessment

data class CharactersResponse(
    val data: List<CharacterEntry>
)

data class CharacterEntry(
    val character: CharacterDetail,
    val role: String,
    val voice_actors: List<VoiceActor>
)

data class CharacterDetail(
    val mal_id: Int,
    val name: String,
    val images: CharacterImages
)

data class CharacterImages(
    val jpg: CharacterImageJpg
)

data class CharacterImageJpg(
    val image_url: String
)

data class VoiceActor(
    val name: String,
    val language: String,
    val images: VoiceActorImages
)

data class VoiceActorImages(
    val jpg: VoiceActorImageJpg
)

data class VoiceActorImageJpg(
    val image_url: String
)