package com.uniquelist.assessment


import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide

class AnimeDetailActivity : AppCompatActivity() {
    private lateinit var viewModel: AnimeDetailViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_anime_detail)

        val animeId = intent.getIntExtra("anime_id", 0)
        viewModel = ViewModelProvider(this)[AnimeDetailViewModel::class.java]

        val titleTV = findViewById<TextView>(R.id.titleTextView)
        val synopsisTV = findViewById<TextView>(R.id.synopsisTextView)
        val genreTV = findViewById<TextView>(R.id.genreTextView)
        val castTV = findViewById<TextView>(R.id.castTextView)
        val episodesTV = findViewById<TextView>(R.id.episodesTextView)
        val ratingTV = findViewById<TextView>(R.id.ratingTextView)
        val videoContainer = findViewById<FrameLayout>(R.id.videoContainer)

        viewModel.animeDetail.observe(this) { anime ->
            anime?.let {
                titleTV.text = it.title
                synopsisTV.text = it.synopsis ?: "No synopsis available"
                genreTV.text = "Genres: " + it.genres.joinToString { g -> g.name }
                castTV.text = "Main Cast: Loading..." // Optional: Fetch character info separately
                episodesTV.text = "Episodes: ${it.episodes ?: "N/A"}"
                ratingTV.text = "Rating: ${it.rating ?: "N/A"}"

                if (!it.trailer?.youtube_id.isNullOrEmpty()) {
                    val videoView = WebView(this).apply {
                        settings.javaScriptEnabled = true
                        loadUrl("https://www.youtube.com/embed/${it.trailer?.youtube_id}")
                    }
                    videoContainer.addView(videoView)
                } else {
                    val imageView = ImageView(this).apply {
                        layoutParams = FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        Glide.with(this@AnimeDetailActivity)
                            .load(it.images.jpg.large_image_url)
                            .into(this)
                    }
                    videoContainer.addView(imageView)
                }
            }
        }

        viewModel.fetchAnimeDetails(animeId)
    }
}
