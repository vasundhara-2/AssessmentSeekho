package com.uniquelist.assessment
data class AnimeResponse(val data: List<AnimeItem>)
