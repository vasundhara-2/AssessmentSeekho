package com.uniquelist.assessment

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide


class AnimeAdapter(
    private val animeList: List<AnimeItem>,
    private val onItemClick: (AnimeItem) -> Unit
) : RecyclerView.Adapter<AnimeAdapter.AnimeViewHolder>() {

    inner class AnimeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.animeTitle)
        val episodes: TextView = itemView.findViewById(R.id.animeEpisodes)
        val rating: TextView = itemView.findViewById(R.id.animeRating)
        val image: ImageView = itemView.findViewById(R.id.animeImage)

        init {
            itemView.setOnClickListener {
                onItemClick(animeList[adapterPosition])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AnimeViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_anime, parent, false)
        return AnimeViewHolder(view)
    }

    override fun onBindViewHolder(holder: AnimeViewHolder, position: Int) {
        val anime = animeList[position]
        holder.title.text = anime.title
        holder.episodes.text = "Episodes: ${anime.episodes ?: "N/A"}"
        holder.rating.text = "Rating: ${anime.score ?: "N/A"}"

        Glide.with(holder.itemView.context)
            .load(anime.images.jpg.image_url)
            .into(holder.image)
    }

    override fun getItemCount(): Int = animeList.size
}