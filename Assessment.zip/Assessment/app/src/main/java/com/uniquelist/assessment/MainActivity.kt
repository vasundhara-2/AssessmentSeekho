package com.uniquelist.assessment

import AnimeListViewModel
import AnimeListViewModelFactory
import AnimeRepository
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var viewModel: AnimeListViewModel
    private lateinit var adapter: AnimeAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.animeRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val repository = AnimeRepository()
        viewModel = ViewModelProvider(this, AnimeListViewModelFactory(repository))[AnimeListViewModel::class.java]

        viewModel.animeList.observe(this) { list ->
            adapter = AnimeAdapter(list) { anime ->
                val intent = Intent(this, AnimeDetailActivity::class.java)
                intent.putExtra("anime_id", anime.mal_id)
                startActivity(intent)
            }
            recyclerView.adapter = adapter
        }

        viewModel.fetchTopAnime()
    }
}