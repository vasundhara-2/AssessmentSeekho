import com.uniquelist.assessment.AnimeDetail
import com.uniquelist.assessment.AnimeItem
import com.uniquelist.assessment.CharacterEntry
import com.uniquelist.assessment.RetrofitInstance

class AnimeRepository {
    suspend fun getTopAnime(): List<AnimeItem> {
        return try {
            val response = RetrofitInstance.api.getTopAnime()
            response.body()?.data ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getAnimeDetails(animeId: Int): AnimeDetail? {
        return try {
            val response = RetrofitInstance.api.getAnimeDetails(animeId)
            response.body()?.data
        } catch (e: Exception) {
            null
        }
    }

    suspend fun getAnimeCast(animeId: Int): List<CharacterEntry> {
        return try {
            val response = RetrofitInstance.api.getAnimeCast(animeId)
            response.body()?.data ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }
}
