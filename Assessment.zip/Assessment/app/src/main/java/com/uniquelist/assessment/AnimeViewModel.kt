import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.uniquelist.assessment.AnimeItem
import kotlinx.coroutines.launch

class AnimeListViewModel(private val repository: AnimeRepository) : ViewModel() {

    private val _animeList = MutableLiveData<List<AnimeItem>>()
    val animeList: LiveData<List<AnimeItem>> = _animeList

    fun fetchTopAnime() {
        viewModelScope.launch {
            _animeList.value = repository.getTopAnime()
        }
    }
}

class AnimeListViewModelFactory(private val repository: AnimeRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return AnimeListViewModel(repository) as T
    }
}
