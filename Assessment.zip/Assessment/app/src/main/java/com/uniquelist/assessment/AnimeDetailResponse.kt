package com.uniquelist.assessment
data class AnimeDetailResponse(
    val data: AnimeDetail
)

data class AnimeDetail(
    val title: String,
    val synopsis: String?,
    val genres: List<Genre>,
    val trailer: Trailer?,
    val images: ImageData,
    val episodes: Int?,
    val rating: String?,
    val characters: List<Character>? = null
)

data class Genre(val name: String)
data class Trailer(val youtube_id: String?)
data class ImageData(val jpg: ImageUrls)
data class ImageUrls(val large_image_url: String)


